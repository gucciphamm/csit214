# UOW Room Booking System — Java Spring Boot prototype

A classroom prototype with separate staff and student accounts, server-side role checks, persistent H2 data, and a clean responsive user interface.

## Mac beginner setup (VS Code)

1. **Install Java JDK 21** (not only the JRE) using https://adoptium.net/temurin/releases/?version=21 . Restart VS Code after installing.
2. Unzip `uow-room-booking.zip` and open the **uow-room-booking** folder in VS Code using **File > Open Folder**. Do not just open an individual Java file.
3. Install these VS Code extensions: **Extension Pack for Java** (Microsoft) and **Spring Boot Extension Pack** (VMware).
4. Open **Terminal > New Terminal** and run the following checks:

   ```bash
   java -version
   javac -version
   ```

   Both must show Java 21 (or another compatible version 21+). If `javac` is missing, run `/usr/libexec/java_home -V` to find installed JDKs. For JDK 21, in **the same terminal**:

   ```bash
   export JAVA_HOME=$(/usr/libexec/java_home -v 21)
   export PATH="$JAVA_HOME/bin:$PATH"
   javac -version
   ```

   If the `/usr/libexec/java_home -v 21` command fails, install JDK 21, then restart VS Code.
5. Verify the terminal is inside the folder with `pom.xml` (use `pwd` and `ls`).
6. Run:

   ```bash
   chmod +x mvnw
   ./mvnw spring-boot:run
   ```

   The bundled `mvnw` script uses your installed Maven or downloads Maven automatically the first time. **First run requires internet** to fetch Maven and Spring dependencies. Wait until you see `Started RoomBookingApplication`.
7. Open **http://localhost:8080** in your browser. Stop with **Ctrl+C** in the terminal.

### Demo logins

| Role | Email | Password |
| --- | --- | --- |
| Staff | `staff@uow.edu.au` | `Staff123!` |
| Student | `student@uow.edu.au` | `Student123!` |

**Important:** These are intentionally preconfigured demo accounts. There is no self-registration, and roles are mutually exclusive in the Java backend. Production use would need UOW SSO/institutional identity verification. Change the seeded passwords before any non-demo deployment.

## Features mapped to assignment requirements

### Staff only
- Create a room with name, location, capacity, hourly price, booking date/time window and optional promotion code + percentage.
- New rooms are **drafts** until staff clicks **Launch room**.
- Update the price, date/time, capacity, promo code and other room details.
- Soft-delete a room if it has no upcoming active bookings. Historical bookings remain recorded.

### Student only
- Browse only launched, non-deleted rooms.
- Select and reserve one **or multiple rooms** in one action (each room is stored as one booking line; it is an atomic transaction).
- Enter attendee count, date/time interval and optional room promotion code.
- See confirmed cost for each room; total = rate per hour × booking duration, minus any applicable discount.
- Modify time, attendees or promotion on an upcoming active booking and see recalculated cost.
- Cancel an upcoming active booking.
- Block overlapping bookings, invalid date ranges, rooms beyond capacity, unlaunched rooms and unavailable time windows.
- Students cannot open staff URLs and staff cannot open student URLs. All modifying actions use CSRF-protected POST requests.

### Honest prototype limitations
- **No actual payments**. The system calculates and records charges; payment gateway integration is out of scope for this demonstration unless required by your lecturer.
- No real university SSO or identity validation. Preapproved demo accounts represent the two university roles.
- Availability is one overall start/end date-time window per room, not recurring daily timetables.
- Changes to an existing room do not retroactively alter agreed charges for existing bookings.
- There are no student refunds, automatic emails or admin report exports.
- H2 file-based database suits a single-machine demonstration, not multi-server production.

## Suggested final-video demonstration (3–5 minutes)

1. Sign in as **staff**. Show the staff dashboard.
2. Create a new room. Show its **Draft** status; it is not visible to students.
3. Click **Launch room**, then edit price, capacity, dates and promo code; save.
4. Sign out and sign in as **student**. Show available rooms, including the newly launched room.
5. Select two rooms. Choose a time inside the room availability window, attendees within both capacities, and book.
6. Scroll to **My bookings** and show charges. Attempt the same room/time to demonstrate overlap prevention.
7. Modify one reservation, then cancel it.
8. Demonstrate access control: while signed in as student, visit `/staff/rooms` and see access denied. Sign in as staff and try `/student/rooms`.
9. Sign in as staff again, show room deletion. (The system blocks deletion while upcoming active bookings remain.)

## Source code map

```text
src/main/java/edu/uow/roombooking/
  RoomBookingApplication.java      # Java entry point
  config/SecurityConfig.java       # Login, role restrictions, CSRF
  config/DemoDataConfig.java       # Seeds demo users and rooms
  controller/AuthController.java   # Login and navigation
  controller/StaffController.java  # Staff actions
  controller/StudentController.java# Student actions
  service/RoomService.java         # Staff room rules
  service/BookingService.java      # Booking rules and pricing
  model/                            # Database entities
  repository/                       # Database access
src/main/resources/
  templates/login.html,staff.html,student.html,denied.html
  static/css/styles.css
  application.properties
src/test/java/                     # Sample automated tests
```

## Run tests

```bash
./mvnw test
```

## Database reset

Data is stored in the `data/` directory, which the app creates automatically. To restore original seeded rooms and clear bookings:

1. Stop the running application (Ctrl+C).
2. Delete the project's `data` directory (do not delete `src`): `rm -rf data`.
3. Restart: `./mvnw spring-boot:run`.

**Warning:** this permanently erases locally saved demo bookings and rooms.

## For the project-management report

Keep your own evidence of team decisions. Suggested deliverables: project charter, stakeholder register, WBS, requirements matrix, schedule/Gantt chart, RACI responsibilities, risk register, change log, test plan/results, meeting minutes and retrospective. Do not submit generic placeholders instead of your actual team records.

## Troubleshooting

- `No compiler is provided... JRE rather than a JDK?` → Check `javac -version`, install/select JDK 21 (see setup step 4).
- `Permission denied: ./mvnw` → Run `chmod +x mvnw`.
- `Address already in use: 8080` → Another app uses port 8080; stop it or change `server.port` in `application.properties`.
- `Could not resolve dependencies` → Internet or corporate network issue during first Maven run.
- `403 Access denied` → Intended when trying to open the wrong role's dashboard.
- `403 on POST` → A custom form may be missing its CSRF hidden field. All provided forms include it.
- `Application start fails because database is locked` → Stop duplicate instances of the app; only one instance should use the same H2 file DB at a time.
