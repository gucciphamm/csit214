package edu.uow.roombooking.controller;

import edu.uow.roombooking.service.BookingService;
import edu.uow.roombooking.service.RoomService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.time.LocalDateTime;
import java.util.List;

@Controller
@RequestMapping("/student")
public class StudentController {
    private final BookingService bookings;
    private final RoomService rooms;

    public StudentController(BookingService bookings, RoomService rooms) {
        this.bookings = bookings;
        this.rooms = rooms;
    }

    @GetMapping("/rooms")
    public String rooms(Model model, Authentication authentication) {
        model.addAttribute("rooms", rooms.publicRooms());
        model.addAttribute("bookings", bookings.forStudent(authentication.getName()));
        model.addAttribute("defaultStart", LocalDateTime.now().plusDays(1).withHour(10).withMinute(0).withSecond(0).withNano(0));
        model.addAttribute("defaultEnd", LocalDateTime.now().plusDays(1).withHour(11).withMinute(0).withSecond(0).withNano(0));
        return "student";
    }

    @PostMapping("/bookings")
    public String book(@RequestParam(required = false) List<Long> roomIds,
                       @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startsAt,
                       @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endsAt,
                       @RequestParam int attendees, @RequestParam(defaultValue = "") String promoCode,
                       Authentication authentication, RedirectAttributes flash) {
        try {
            int count = bookings.book(authentication.getName(), roomIds, startsAt, endsAt, attendees, promoCode);
            flash.addFlashAttribute("success", count + " room(s) booked successfully. Your charges are shown below.");
        } catch (IllegalArgumentException ex) {
            flash.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/student/rooms";
    }

    @PostMapping("/bookings/{id}/update")
    public String update(@PathVariable Long id,
                         @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startsAt,
                         @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endsAt,
                         @RequestParam int attendees, @RequestParam(defaultValue = "") String promoCode,
                         Authentication authentication, RedirectAttributes flash) {
        try {
            bookings.modify(authentication.getName(), id, startsAt, endsAt, attendees, promoCode);
            flash.addFlashAttribute("success", "Booking modified and price recalculated.");
        } catch (IllegalArgumentException ex) {
            flash.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/student/rooms#my-bookings";
    }

    @PostMapping("/bookings/{id}/cancel")
    public String cancel(@PathVariable Long id, Authentication authentication, RedirectAttributes flash) {
        try {
            bookings.cancel(authentication.getName(), id);
            flash.addFlashAttribute("success", "Booking cancelled.");
        } catch (IllegalArgumentException ex) {
            flash.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/student/rooms#my-bookings";
    }
}
