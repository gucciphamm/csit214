package edu.uow.roombooking.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "rooms")
public class Room {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String location;

    @Column(nullable = false)
    private int capacity;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal pricePerHour;

    @Column(nullable = false)
    private LocalDateTime availableFrom;

    @Column(nullable = false)
    private LocalDateTime availableUntil;

    private String promoCode;
    private int promoPercent;
    private boolean launched = false;
    private boolean deleted = false;

    protected Room() {}

    public Room(String name, String location, int capacity, BigDecimal pricePerHour,
                LocalDateTime availableFrom, LocalDateTime availableUntil,
                String promoCode, int promoPercent) {
        update(name, location, capacity, pricePerHour, availableFrom, availableUntil, promoCode, promoPercent);
    }

    public void update(String name, String location, int capacity, BigDecimal pricePerHour,
                       LocalDateTime availableFrom, LocalDateTime availableUntil,
                       String promoCode, int promoPercent) {
        this.name = name;
        this.location = location;
        this.capacity = capacity;
        this.pricePerHour = pricePerHour;
        this.availableFrom = availableFrom;
        this.availableUntil = availableUntil;
        this.promoCode = promoCode;
        this.promoPercent = promoPercent;
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public String getLocation() { return location; }
    public int getCapacity() { return capacity; }
    public BigDecimal getPricePerHour() { return pricePerHour; }
    public LocalDateTime getAvailableFrom() { return availableFrom; }
    public LocalDateTime getAvailableUntil() { return availableUntil; }
    public String getPromoCode() { return promoCode; }
    public int getPromoPercent() { return promoPercent; }
    public boolean isLaunched() { return launched; }
    public boolean isDeleted() { return deleted; }
    public void setLaunched(boolean launched) { this.launched = launched; }
    public void setDeleted(boolean deleted) { this.deleted = deleted; }
}
