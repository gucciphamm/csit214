package edu.uow.roombooking.model;

public enum Role {
    STAFF, STUDENT
}
