package edu.uow.roombooking.controller;

import edu.uow.roombooking.service.RoomService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Controller
@RequestMapping("/staff")
public class StaffController {
    private final RoomService rooms;

    public StaffController(RoomService rooms) { this.rooms = rooms; }

    @GetMapping("/rooms")
    public String rooms(Model model) {
        model.addAttribute("rooms", rooms.allManagedRooms());
        model.addAttribute("defaultFrom", LocalDateTime.now().plusDays(1).withHour(9).withMinute(0).withSecond(0).withNano(0));
        model.addAttribute("defaultUntil", LocalDateTime.now().plusMonths(1).withHour(18).withMinute(0).withSecond(0).withNano(0));
        return "staff";
    }

    @PostMapping("/rooms")
    public String create(@RequestParam String name, @RequestParam String location,
                         @RequestParam int capacity, @RequestParam BigDecimal pricePerHour,
                         @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime availableFrom,
                         @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime availableUntil,
                         @RequestParam(defaultValue = "") String promoCode,
                         @RequestParam(defaultValue = "0") int promoPercent,
                         RedirectAttributes flash) {
        try {
            rooms.create(name, location, capacity, pricePerHour, availableFrom, availableUntil,
                promoCode, promoPercent);
            flash.addFlashAttribute("success", "Room created as draft. Click Launch to make it bookable.");
        } catch (IllegalArgumentException ex) {
            flash.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/staff/rooms";
    }

    @PostMapping("/rooms/{id}/update")
    public String update(@PathVariable Long id, @RequestParam String name,
                         @RequestParam String location, @RequestParam int capacity,
                         @RequestParam BigDecimal pricePerHour,
                         @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime availableFrom,
                         @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime availableUntil,
                         @RequestParam(defaultValue = "") String promoCode,
                         @RequestParam(defaultValue = "0") int promoPercent,
                         RedirectAttributes flash) {
        try {
            rooms.update(id, name, location, capacity, pricePerHour, availableFrom,
                availableUntil, promoCode, promoPercent);
            flash.addFlashAttribute("success", "Room details updated.");
        } catch (IllegalArgumentException ex) {
            flash.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/staff/rooms";
    }

    @PostMapping("/rooms/{id}/launch")
    public String launch(@PathVariable Long id, RedirectAttributes flash) {
        try {
            rooms.launch(id);
            flash.addFlashAttribute("success", "Room launched. Students can now book it.");
        } catch (IllegalArgumentException ex) {
            flash.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/staff/rooms";
    }

    @PostMapping("/rooms/{id}/delete")
    public String delete(@PathVariable Long id, RedirectAttributes flash) {
        try {
            rooms.delete(id);
            flash.addFlashAttribute("success", "Room deleted from the catalogue.");
        } catch (IllegalArgumentException ex) {
            flash.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/staff/rooms";
    }
}
