package edu.uow.roombooking.service;

import edu.uow.roombooking.model.*;
import edu.uow.roombooking.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class BookingService {
    private final BookingRepository bookings;
    private final RoomRepository rooms;
    private final UserAccountRepository users;

    public BookingService(BookingRepository bookings, RoomRepository rooms, UserAccountRepository users) {
        this.bookings = bookings;
        this.rooms = rooms;
        this.users = users;
    }

    @Transactional(readOnly = true)
    public List<Booking> forStudent(String email) {
        return bookings.findByStudent_IdOrderByCreatedAtDesc(student(email).getId());
    }

    /** A multi-room booking creates one line-item per room, all in one atomic transaction. */
    @Transactional
    public int book(String email, List<Long> roomIds, LocalDateTime start,
                    LocalDateTime end, int attendees, String promoCode) {
        validateTime(start, end);
        if (roomIds == null || roomIds.isEmpty())
            throw new IllegalArgumentException("Select at least one room.");
        if (roomIds.size() > 20)
            throw new IllegalArgumentException("Book at most 20 rooms at once.");

        UserAccount student = student(email);
        List<Long> uniqueIds = roomIds.stream().filter(Objects::nonNull).distinct().sorted().toList();
        if (uniqueIds.isEmpty()) throw new IllegalArgumentException("Select at least one room.");
        List<Booking> newBookings = new ArrayList<>();
        boolean anyPromoApplied = false;

        // Lock rooms in stable order. Competing bookings cannot pass the overlap check together.
        for (Long id : uniqueIds) {
            Room room = rooms.findByIdForUpdate(id)
                .orElseThrow(() -> new IllegalArgumentException("Room no longer exists: " + id));
            ensureBookable(room, start, end, attendees, null);
            Quote quote = calculate(room, start, end, promoCode);
            anyPromoApplied |= quote.promoApplied();
            newBookings.add(new Booking(student, room, start, end, attendees,
                quote.price(), quote.promoApplied() ? room.getPromoCode() : null));
        }
        if (promoCode != null && !promoCode.isBlank() && !anyPromoApplied)
            throw new IllegalArgumentException("Promotion code is not valid for the selected rooms.");
        bookings.saveAll(newBookings);
        return newBookings.size();
    }

    @Transactional
    public void modify(String email, Long bookingId, LocalDateTime start,
                       LocalDateTime end, int attendees, String promoCode) {
        validateTime(start, end);
        Booking booking = ownedActiveBooking(email, bookingId);
        if (!booking.getStartsAt().isAfter(LocalDateTime.now()))
            throw new IllegalArgumentException("A booking that has already started cannot be modified.");
        Room room = rooms.findByIdForUpdate(booking.getRoom().getId())
            .orElseThrow(() -> new IllegalArgumentException("Room unavailable."));
        ensureBookable(room, start, end, attendees, bookingId);
        Quote quote = calculate(room, start, end, promoCode);
        if (promoCode != null && !promoCode.isBlank() && !quote.promoApplied())
            throw new IllegalArgumentException("Promotion code is not valid for this room.");
        booking.update(start, end, attendees, quote.price(),
            quote.promoApplied() ? room.getPromoCode() : null);
    }

    @Transactional
    public void cancel(String email, Long bookingId) {
        Booking booking = ownedActiveBooking(email, bookingId);
        if (!booking.getStartsAt().isAfter(LocalDateTime.now()))
            throw new IllegalArgumentException("A booking that has already started cannot be cancelled.");
        booking.cancel();
    }

    private Booking ownedActiveBooking(String email, Long id) {
        if (id == null) throw new IllegalArgumentException("Booking ID required.");
        Booking booking = bookings.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Booking not found."));
        if (!booking.getStudent().getEmail().equals(email))
            throw new IllegalArgumentException("You may only modify your own bookings.");
        if (booking.getStatus() != BookingStatus.ACTIVE)
            throw new IllegalArgumentException("This booking is already cancelled.");
        return booking;
    }

    private UserAccount student(String email) {
        UserAccount account = users.findByEmail(email)
            .orElseThrow(() -> new IllegalArgumentException("User account not found."));
        if (account.getRole() != Role.STUDENT)
            throw new IllegalArgumentException("Only a student can make reservations.");
        return account;
    }

    private void ensureBookable(Room room, LocalDateTime start, LocalDateTime end,
                                int attendees, Long excludeBookingId) {
        if (room.isDeleted() || !room.isLaunched())
            throw new IllegalArgumentException(room.getName() + " is not available for reservations.");
        if (attendees < 1 || attendees > room.getCapacity())
            throw new IllegalArgumentException(room.getName() + " accommodates 1 to " + room.getCapacity() + " people.");
        if (start.isBefore(room.getAvailableFrom()) || end.isAfter(room.getAvailableUntil()))
            throw new IllegalArgumentException(room.getName() + " is unavailable during the requested time.");
        if (bookings.countOverlaps(room.getId(), BookingStatus.ACTIVE, start, end, excludeBookingId) > 0)
            throw new IllegalArgumentException(room.getName() + " is already reserved during this time.");
    }

    static void validateTime(LocalDateTime start, LocalDateTime end) {
        if (start == null || end == null || !start.isAfter(LocalDateTime.now()))
            throw new IllegalArgumentException("Start time must be in the future.");
        long minutes = Duration.between(start, end).toMinutes();
        if (!end.isAfter(start) || minutes < 30 || minutes > 24 * 60)
            throw new IllegalArgumentException("Bookings must be from 30 minutes to 24 hours.");
    }

    static Quote calculate(Room room, LocalDateTime start, LocalDateTime end, String code) {
        long minutes = Duration.between(start, end).toMinutes();
        BigDecimal hours = BigDecimal.valueOf(minutes)
            .divide(BigDecimal.valueOf(60), 8, RoundingMode.HALF_UP);
        BigDecimal total = room.getPricePerHour().multiply(hours);
        boolean applied = code != null && !code.isBlank() && room.getPromoPercent() > 0
            && code.trim().equalsIgnoreCase(room.getPromoCode());
        if (applied) {
            total = total.multiply(BigDecimal.valueOf(100 - room.getPromoPercent()))
                .divide(BigDecimal.valueOf(100), 8, RoundingMode.HALF_UP);
        }
        return new Quote(total.setScale(2, RoundingMode.HALF_UP), applied);
    }

    record Quote(BigDecimal price, boolean promoApplied) {}
}
