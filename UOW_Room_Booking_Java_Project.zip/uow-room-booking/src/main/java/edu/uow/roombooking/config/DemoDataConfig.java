package edu.uow.roombooking.config;

import edu.uow.roombooking.model.*;
import edu.uow.roombooking.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.math.BigDecimal;
import java.time.LocalDate;

@Configuration
public class DemoDataConfig {
    @Bean
    CommandLineRunner seedDemo(UserAccountRepository users, RoomRepository rooms,
                               PasswordEncoder encoder) {
        return args -> {
            // Accounts are preapproved by role. There is intentionally no public registration.
            if (users.findByEmail("staff@uow.edu.au").isEmpty()) {
                users.save(new UserAccount("staff@uow.edu.au", encoder.encode("Staff123!"),
                    "Alex Morgan", Role.STAFF));
            }
            if (users.findByEmail("student@uow.edu.au").isEmpty()) {
                users.save(new UserAccount("student@uow.edu.au", encoder.encode("Student123!"),
                    "Jamie Lee", Role.STUDENT));
            }
            if (rooms.count() == 0) {
                LocalDate tomorrow = LocalDate.now().plusDays(1);
                Room a = new Room("Study Room A101", "Library • Level 1", 6,
                    new BigDecimal("12.00"), tomorrow.atStartOfDay(),
                    tomorrow.plusMonths(6).atTime(23, 59), "STUDY10", 10);
                a.setLaunched(true);
                rooms.save(a);
                Room b = new Room("Seminar Room B202", "Building B • Level 2", 20,
                    new BigDecimal("25.00"), tomorrow.atStartOfDay(),
                    tomorrow.plusMonths(6).atTime(23, 59), "", 0);
                b.setLaunched(true);
                rooms.save(b);
                Room c = new Room("Collaboration Room C303", "Learning Hub • Level 3", 8,
                    new BigDecimal("18.00"), tomorrow.atStartOfDay(),
                    tomorrow.plusMonths(6).atTime(23, 59), "WELCOME15", 15);
                rooms.save(c); // Deliberately not launched: staff demonstrates launching.
            }
        };
    }
}
