package edu.uow.roombooking.repository;

import edu.uow.roombooking.model.Booking;
import edu.uow.roombooking.model.BookingStatus;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.time.LocalDateTime;
import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByStudent_IdOrderByCreatedAtDesc(Long studentId);
    List<Booking> findByRoom_IdAndStatus(Long roomId, BookingStatus status);

    @Query("select count(b) from Booking b where b.room.id = :roomId and b.status = :status " +
           "and b.startsAt < :endsAt and b.endsAt > :startsAt " +
           "and (:excludeId is null or b.id <> :excludeId)")
    long countOverlaps(@Param("roomId") Long roomId, @Param("status") BookingStatus status,
                       @Param("startsAt") LocalDateTime startsAt, @Param("endsAt") LocalDateTime endsAt,
                       @Param("excludeId") Long excludeId);
}
