package edu.uow.roombooking.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AuthController {
    @GetMapping("/")
    public String home() { return "redirect:/dashboard"; }

    @GetMapping("/login")
    public String login() { return "login"; }

    @GetMapping("/dashboard")
    public String dashboard(Authentication authentication) {
        boolean staff = authentication.getAuthorities().stream()
            .map(GrantedAuthority::getAuthority).anyMatch("ROLE_STAFF"::equals);
        return staff ? "redirect:/staff/rooms" : "redirect:/student/rooms";
    }

    @GetMapping("/access-denied")
    public String denied() { return "denied"; }
}
