package edu.uow.roombooking.service;

import edu.uow.roombooking.model.*;
import edu.uow.roombooking.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;

@Service
public class RoomService {
    private final RoomRepository rooms;
    private final BookingRepository bookings;

    public RoomService(RoomRepository rooms, BookingRepository bookings) {
        this.rooms = rooms;
        this.bookings = bookings;
    }

    @Transactional(readOnly = true)
    public List<Room> allManagedRooms() { return rooms.findByDeletedFalseOrderByIdDesc(); }

    @Transactional(readOnly = true)
    public List<Room> publicRooms() { return rooms.findByDeletedFalseAndLaunchedTrueOrderByIdAsc(); }

    @Transactional
    public void create(String name, String location, int capacity, BigDecimal price,
                       LocalDateTime from, LocalDateTime until, String promo, int percent) {
        validate(name, location, capacity, price, from, until, promo, percent);
        rooms.save(new Room(name.trim(), location.trim(), capacity, price, from, until,
            cleanPromo(promo), percent));
    }

    @Transactional
    public void update(Long id, String name, String location, int capacity, BigDecimal price,
                       LocalDateTime from, LocalDateTime until, String promo, int percent) {
        validate(name, location, capacity, price, from, until, promo, percent);
        Room room = getLockedActive(id);
        for (Booking booking : bookings.findByRoom_IdAndStatus(id, BookingStatus.ACTIVE)) {
            if (booking.getStartsAt().isBefore(from) || booking.getEndsAt().isAfter(until)) {
                throw new IllegalArgumentException("The new availability excludes an existing booking.");
            }
            if (booking.getAttendees() > capacity) {
                throw new IllegalArgumentException("The new capacity is smaller than an existing booking's attendees.");
            }
        }
        room.update(name.trim(), location.trim(), capacity, price, from, until,
            cleanPromo(promo), percent);
    }

    @Transactional
    public void launch(Long id) {
        Room room = getLockedActive(id);
        room.setLaunched(true);
    }

    @Transactional
    public void delete(Long id) {
        Room room = getLockedActive(id);
        boolean hasUpcomingBookings = bookings.findByRoom_IdAndStatus(id, BookingStatus.ACTIVE)
            .stream().anyMatch(b -> b.getEndsAt().isAfter(LocalDateTime.now()));
        if (hasUpcomingBookings) {
            throw new IllegalArgumentException("Cannot delete a room with active upcoming bookings. Cancel them first.");
        }
        room.setDeleted(true); // Soft deletion preserves booking history.
        room.setLaunched(false);
    }

    private Room getLockedActive(Long id) {
        if (id == null) throw new IllegalArgumentException("Room ID is required.");
        Room room = rooms.findByIdForUpdate(id)
            .orElseThrow(() -> new IllegalArgumentException("Room not found."));
        if (room.isDeleted()) throw new IllegalArgumentException("Room has been deleted.");
        return room;
    }

    static void validate(String name, String location, int capacity, BigDecimal price,
                         LocalDateTime from, LocalDateTime until, String promo, int percent) {
        if (name == null || name.isBlank() || name.length() > 80)
            throw new IllegalArgumentException("Room name is required (max 80 characters).");
        if (location == null || location.isBlank() || location.length() > 120)
            throw new IllegalArgumentException("Location is required (max 120 characters).");
        if (capacity < 1 || capacity > 1000)
            throw new IllegalArgumentException("Capacity must be between 1 and 1000.");
        if (price == null || price.compareTo(BigDecimal.ZERO) <= 0
            || price.compareTo(new BigDecimal("100000")) > 0)
            throw new IllegalArgumentException("Hourly price must be greater than 0 and at most 100000.");
        if (from == null || until == null || !until.isAfter(from))
            throw new IllegalArgumentException("Availability end must be after start.");
        if (percent < 0 || percent > 90)
            throw new IllegalArgumentException("Promotion discount must be between 0 and 90%.");
        if (promo != null && promo.length() > 30)
            throw new IllegalArgumentException("Promotion code must be 30 characters or fewer.");
        if (percent > 0 && (promo == null || promo.isBlank()))
            throw new IllegalArgumentException("Enter a promotion code if discount is greater than 0.");
        if (percent == 0 && promo != null && !promo.isBlank())
            throw new IllegalArgumentException("Enter a promotion discount percentage or clear the promotion code.");
    }

    static String cleanPromo(String promo) {
        return promo == null ? "" : promo.trim().toUpperCase(Locale.ROOT);
    }
}
