package edu.uow.roombooking.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "bookings", indexes = @Index(name = "idx_room_time", columnList = "room_id, starts_at, ends_at"))
public class Booking {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    private UserAccount student;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    private Room room;

    @Column(nullable = false)
    private LocalDateTime startsAt;

    @Column(nullable = false)
    private LocalDateTime endsAt;

    private int attendees;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal totalPrice;

    private String appliedPromo;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private BookingStatus status = BookingStatus.ACTIVE;

    @Column(nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    protected Booking() {}

    public Booking(UserAccount student, Room room, LocalDateTime startsAt, LocalDateTime endsAt,
                   int attendees, BigDecimal totalPrice, String appliedPromo) {
        this.student = student;
        this.room = room;
        update(startsAt, endsAt, attendees, totalPrice, appliedPromo);
    }

    public void update(LocalDateTime startsAt, LocalDateTime endsAt, int attendees,
                       BigDecimal totalPrice, String appliedPromo) {
        this.startsAt = startsAt;
        this.endsAt = endsAt;
        this.attendees = attendees;
        this.totalPrice = totalPrice;
        this.appliedPromo = appliedPromo;
    }

    public Long getId() { return id; }
    public UserAccount getStudent() { return student; }
    public Room getRoom() { return room; }
    public LocalDateTime getStartsAt() { return startsAt; }
    public LocalDateTime getEndsAt() { return endsAt; }
    public int getAttendees() { return attendees; }
    public BigDecimal getTotalPrice() { return totalPrice; }
    public String getAppliedPromo() { return appliedPromo; }
    public BookingStatus getStatus() { return status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void cancel() { this.status = BookingStatus.CANCELLED; }
}
