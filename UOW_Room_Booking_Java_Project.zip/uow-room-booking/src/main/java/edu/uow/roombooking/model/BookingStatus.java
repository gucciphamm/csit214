package edu.uow.roombooking.model;

public enum BookingStatus {
    ACTIVE, CANCELLED
}
