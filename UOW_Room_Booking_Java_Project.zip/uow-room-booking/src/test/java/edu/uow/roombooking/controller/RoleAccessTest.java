package edu.uow.roombooking.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(properties = {
    "spring.datasource.url=jdbc:h2:mem:roleaccesstests;DB_CLOSE_DELAY=-1",
    "spring.jpa.hibernate.ddl-auto=create-drop"
})
@AutoConfigureMockMvc
class RoleAccessTest {
    @Autowired MockMvc mvc;

    @Test
    @WithMockUser(roles = "STUDENT")
    void studentCannotOpenStaffDashboard() throws Exception {
        mvc.perform(get("/staff/rooms")).andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(roles = "STAFF")
    void staffCannotOpenStudentDashboard() throws Exception {
        mvc.perform(get("/student/rooms")).andExpect(status().isForbidden());
    }
}
