package edu.uow.roombooking.service;

import edu.uow.roombooking.model.BookingStatus;
import edu.uow.roombooking.model.Room;
import edu.uow.roombooking.repository.BookingRepository;
import edu.uow.roombooking.repository.RoomRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(properties = {
    "spring.datasource.url=jdbc:h2:mem:bookingtests;DB_CLOSE_DELAY=-1",
    "spring.jpa.hibernate.ddl-auto=create-drop"
})
@Transactional
class BookingServiceTest {
    @Autowired BookingService bookingService;
    @Autowired RoomRepository roomRepository;
    @Autowired BookingRepository bookingRepository;

    private LocalDateTime futureStart() {
        return LocalDateTime.now().plusDays(3).withHour(10).withMinute(0).withSecond(0).withNano(0);
    }

    @Test
    void booksMultipleRoomsAndCalculatesPrice() {
        List<Room> available = roomRepository.findByDeletedFalseAndLaunchedTrueOrderByIdAsc();
        assertTrue(available.size() >= 2);
        LocalDateTime start = futureStart();
        int count = bookingService.book("student@uow.edu.au",
            List.of(available.get(0).getId(), available.get(1).getId()),
            start, start.plusHours(2), 2, "");
        assertEquals(2, count);
        assertEquals(2, bookingService.forStudent("student@uow.edu.au").size());
    }

    @Test
    void rejectsOverlappingBookings() {
        Room first = roomRepository.findByDeletedFalseAndLaunchedTrueOrderByIdAsc().get(0);
        LocalDateTime start = futureStart();
        bookingService.book("student@uow.edu.au", List.of(first.getId()), start, start.plusHours(2), 2, "");
        assertThrows(IllegalArgumentException.class, () ->
            bookingService.book("student@uow.edu.au", List.of(first.getId()),
                start.plusHours(1), start.plusHours(3), 2, ""));
        assertEquals(1, bookingRepository.findByRoom_IdAndStatus(first.getId(), BookingStatus.ACTIVE).size());
    }

    @Test
    void rejectsBookingAboveRoomCapacity() {
        Room first = roomRepository.findByDeletedFalseAndLaunchedTrueOrderByIdAsc().get(0);
        LocalDateTime start = futureStart();
        assertThrows(IllegalArgumentException.class, () ->
            bookingService.book("student@uow.edu.au", List.of(first.getId()),
                start, start.plusHours(1), first.getCapacity() + 1, ""));
    }

    @Test
    void promotionalPricingReducesCharge() {
        LocalDateTime start = futureStart();
        Room testRoom = new Room("Test Room", "Test Building", 10, new BigDecimal("20.00"),
            start.minusDays(1), start.plusDays(1), "TEST10", 10);
        var result = BookingService.calculate(testRoom, start, start.plusMinutes(90), "test10");
        assertTrue(result.promoApplied());
        assertEquals(new BigDecimal("27.00"), result.price());
    }
}
